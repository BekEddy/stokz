module.exports = {
  plugins: {
    'postcss-import': {},
    'postcss-preset-mantine': {},
    'tailwindcss/nesting': 'postcss-nesting',
    tailwindcss: {},
    // 'postcss-preset-env': {
    //   features: { 'nesting-rules': true },
    // },
    autoprefixer: {},
  },
}

// 'postcss-nesting': {},
