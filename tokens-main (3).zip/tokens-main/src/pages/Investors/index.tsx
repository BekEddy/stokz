import { Title } from '@mantine/core'

const Investors = () => {
  return (
    <div>
      <Title order={3} c="#FFFFFF">
        Investors
      </Title>
    </div>
  )
}

export default Investors
